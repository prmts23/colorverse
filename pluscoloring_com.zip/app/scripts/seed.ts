
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const categories = [
  // Animals (HIGHEST PRIORITY) - 25 categories
  { name: 'Dogs', slug: 'dogs', description: 'Cute dog coloring pages for kids and adults', searchVolume: 4225, priority: 1, icon: '🐕' },
  { name: 'Cats', slug: 'cats', description: 'Adorable cat coloring pages', searchVolume: 6321, priority: 2, icon: '🐈' },
  { name: 'Birds', slug: 'birds', description: 'Beautiful bird coloring pages', searchVolume: 2100, priority: 3, icon: '🦜' },
  { name: 'Dinosaurs', slug: 'dinosaurs', description: 'Prehistoric dinosaur coloring pages', searchVolume: 3500, priority: 4, icon: '🦕' },
  { name: 'Farm Animals', slug: 'farm-animals', description: 'Farm animal coloring pages', searchVolume: 2800, priority: 5, icon: '🐄' },
  { name: 'Zoo Animals', slug: 'zoo-animals', description: 'Zoo animal coloring pages', searchVolume: 2200, priority: 6, icon: '🦁' },
  { name: 'Wild Animals', slug: 'wild-animals', description: 'Wild animal coloring pages', searchVolume: 2600, priority: 7, icon: '🐯' },
  { name: 'Marine Animals', slug: 'marine-animals', description: 'Ocean and sea animal coloring pages', searchVolume: 1900, priority: 8, icon: '🐠' },
  { name: 'Insects', slug: 'insects', description: 'Insect and bug coloring pages', searchVolume: 1500, priority: 9, icon: '🐞' },
  { name: 'Horses', slug: 'horses', description: 'Beautiful horse coloring pages', searchVolume: 2400, priority: 10, icon: '🐴' },
  { name: 'Rabbits', slug: 'rabbits', description: 'Cute rabbit and bunny coloring pages', searchVolume: 1800, priority: 11, icon: '🐰' },
  { name: 'Bears', slug: 'bears', description: 'Bear coloring pages for kids', searchVolume: 1600, priority: 12, icon: '🐻' },
  { name: 'Elephants', slug: 'elephants', description: 'Elephant coloring pages', searchVolume: 1400, priority: 13, icon: '🐘' },
  { name: 'Monkeys', slug: 'monkeys', description: 'Playful monkey coloring pages', searchVolume: 1300, priority: 14, icon: '🐒' },
  { name: 'Lions', slug: 'lions', description: 'Lion coloring pages', searchVolume: 1200, priority: 15, icon: '🦁' },
  { name: 'Tigers', slug: 'tigers', description: 'Tiger coloring pages', searchVolume: 1100, priority: 16, icon: '🐅' },
  { name: 'Wolves', slug: 'wolves', description: 'Wolf coloring pages', searchVolume: 1000, priority: 17, icon: '🐺' },
  { name: 'Dolphins', slug: 'dolphins', description: 'Dolphin coloring pages', searchVolume: 1250, priority: 18, icon: '🐬' },
  { name: 'Sharks', slug: 'sharks', description: 'Shark coloring pages', searchVolume: 1350, priority: 19, icon: '🦈' },
  { name: 'Butterflies', slug: 'butterflies', description: 'Beautiful butterfly coloring pages', searchVolume: 2000, priority: 20, icon: '🦋' },
  { name: 'Owls', slug: 'owls', description: 'Owl coloring pages', searchVolume: 1450, priority: 21, icon: '🦉' },
  { name: 'Frogs', slug: 'frogs', description: 'Frog coloring pages', searchVolume: 900, priority: 22, icon: '🐸' },
  { name: 'Turtles', slug: 'turtles', description: 'Turtle coloring pages', searchVolume: 950, priority: 23, icon: '🐢' },
  { name: 'Penguins', slug: 'penguins', description: 'Penguin coloring pages', searchVolume: 1100, priority: 24, icon: '🐧' },
  { name: 'Giraffes', slug: 'giraffes', description: 'Giraffe coloring pages', searchVolume: 850, priority: 25, icon: '🦒' },

  // Disney & Cartoon Characters - 15 categories
  { name: 'Mickey Mouse', slug: 'mickey-mouse', description: 'Mickey Mouse coloring pages', searchVolume: 5000, priority: 26, icon: '🐭' },
  { name: 'Disney Princesses', slug: 'disney-princesses', description: 'Disney princess coloring pages', searchVolume: 4500, priority: 27, icon: '👸' },
  { name: 'Frozen', slug: 'frozen', description: 'Frozen coloring pages with Elsa and Anna', searchVolume: 4200, priority: 28, icon: '❄️' },
  { name: 'Paw Patrol', slug: 'paw-patrol', description: 'Paw Patrol coloring pages', searchVolume: 3800, priority: 29, icon: '🐾' },
  { name: 'Peppa Pig', slug: 'peppa-pig', description: 'Peppa Pig coloring pages', searchVolume: 3500, priority: 30, icon: '🐷' },
  { name: 'Minnie Mouse', slug: 'minnie-mouse', description: 'Minnie Mouse coloring pages', searchVolume: 2900, priority: 31, icon: '🎀' },
  { name: 'Winnie the Pooh', slug: 'winnie-the-pooh', description: 'Winnie the Pooh coloring pages', searchVolume: 2600, priority: 32, icon: '🍯' },
  { name: 'Toy Story', slug: 'toy-story', description: 'Toy Story coloring pages', searchVolume: 2400, priority: 33, icon: '🤠' },
  { name: 'Finding Nemo', slug: 'finding-nemo', description: 'Finding Nemo coloring pages', searchVolume: 2100, priority: 34, icon: '🐠' },
  { name: 'The Lion King', slug: 'the-lion-king', description: 'Lion King coloring pages', searchVolume: 2000, priority: 35, icon: '👑' },
  { name: 'Moana', slug: 'moana', description: 'Moana coloring pages', searchVolume: 1900, priority: 36, icon: '🌺' },
  { name: 'Encanto', slug: 'encanto', description: 'Encanto coloring pages', searchVolume: 1800, priority: 37, icon: '🦋' },
  { name: 'Disney Cars', slug: 'cars-movie', description: 'Disney Cars coloring pages', searchVolume: 2300, priority: 38, icon: '🏎️' },
  { name: 'SpongeBob', slug: 'spongebob', description: 'SpongeBob SquarePants coloring pages', searchVolume: 3200, priority: 39, icon: '🧽' },
  { name: 'Sonic', slug: 'sonic', description: 'Sonic the Hedgehog coloring pages', searchVolume: 2700, priority: 40, icon: '💨' },

  // Video Games - 8 categories
  { name: 'Minecraft', slug: 'minecraft', description: 'Minecraft coloring pages', searchVolume: 4800, priority: 41, icon: '⛏️' },
  { name: 'Pokemon', slug: 'pokemon', description: 'Pokemon coloring pages', searchVolume: 5200, priority: 42, icon: '⚡' },
  { name: 'Fortnite', slug: 'fortnite', description: 'Fortnite coloring pages', searchVolume: 3400, priority: 43, icon: '🎮' },
  { name: 'Roblox', slug: 'roblox', description: 'Roblox coloring pages', searchVolume: 3100, priority: 44, icon: '🎲' },
  { name: 'Among Us', slug: 'among-us', description: 'Among Us coloring pages', searchVolume: 2800, priority: 45, icon: '👾' },
  { name: 'Super Mario', slug: 'super-mario', description: 'Super Mario coloring pages', searchVolume: 3600, priority: 46, icon: '🍄' },
  { name: 'Angry Birds', slug: 'angry-birds', description: 'Angry Birds coloring pages', searchVolume: 2200, priority: 47, icon: '😠' },
  { name: 'Five Nights at Freddys', slug: 'fnaf', description: 'FNAF coloring pages', searchVolume: 2500, priority: 48, icon: '🐻' },

  // Holidays & Seasonal - 10 categories
  { name: 'Christmas', slug: 'christmas', description: 'Christmas coloring pages', searchVolume: 10404, priority: 49, icon: '🎄' },
  { name: 'Halloween', slug: 'halloween', description: 'Halloween coloring pages', searchVolume: 8500, priority: 50, icon: '🎃' },
  { name: 'Easter', slug: 'easter', description: 'Easter coloring pages', searchVolume: 6200, priority: 51, icon: '🐰' },
  { name: 'Thanksgiving', slug: 'thanksgiving', description: 'Thanksgiving coloring pages', searchVolume: 4500, priority: 52, icon: '🦃' },
  { name: 'Valentines Day', slug: 'valentines-day', description: 'Valentine\'s Day coloring pages', searchVolume: 5100, priority: 53, icon: '💝' },
  { name: 'Birthday', slug: 'birthday', description: 'Birthday coloring pages', searchVolume: 3800, priority: 54, icon: '🎂' },
  { name: 'New Year', slug: 'new-year', description: 'New Year coloring pages', searchVolume: 2400, priority: 55, icon: '🎆' },
  { name: 'Spring', slug: 'spring', description: 'Spring coloring pages', searchVolume: 2100, priority: 56, icon: '🌸' },
  { name: 'Summer', slug: 'summer', description: 'Summer coloring pages', searchVolume: 2300, priority: 57, icon: '☀️' },
  { name: 'Winter', slug: 'winter', description: 'Winter coloring pages', searchVolume: 2000, priority: 58, icon: '⛄' },

  // Superheroes & Popular Culture - 8 categories
  { name: 'Spider-Man', slug: 'spider-man', description: 'Spider-Man coloring pages', searchVolume: 4100, priority: 59, icon: '🕷️' },
  { name: 'Batman', slug: 'batman', description: 'Batman coloring pages', searchVolume: 3700, priority: 60, icon: '🦇' },
  { name: 'Superman', slug: 'superman', description: 'Superman coloring pages', searchVolume: 2900, priority: 61, icon: '🦸' },
  { name: 'Avengers', slug: 'avengers', description: 'Avengers coloring pages', searchVolume: 3300, priority: 62, icon: '⚡' },
  { name: 'Wonder Woman', slug: 'wonder-woman', description: 'Wonder Woman coloring pages', searchVolume: 2100, priority: 63, icon: '⭐' },
  { name: 'Star Wars', slug: 'star-wars', description: 'Star Wars coloring pages', searchVolume: 3900, priority: 64, icon: '⚔️' },
  { name: 'Harry Potter', slug: 'harry-potter', description: 'Harry Potter coloring pages', searchVolume: 3400, priority: 65, icon: '⚡' },
  { name: 'Transformers', slug: 'transformers', description: 'Transformers coloring pages', searchVolume: 2300, priority: 66, icon: '🤖' },

  // Fantasy & Mythology - 8 categories
  { name: 'Unicorns', slug: 'unicorns', description: 'Magical unicorn coloring pages', searchVolume: 4600, priority: 67, icon: '🦄' },
  { name: 'Dragons', slug: 'dragons', description: 'Dragon coloring pages', searchVolume: 3800, priority: 68, icon: '🐉' },
  { name: 'Fairies', slug: 'fairies', description: 'Fairy coloring pages', searchVolume: 2900, priority: 69, icon: '🧚' },
  { name: 'Mermaids', slug: 'mermaids', description: 'Mermaid coloring pages', searchVolume: 3200, priority: 70, icon: '🧜' },
  { name: 'Angels', slug: 'angels', description: 'Angel coloring pages', searchVolume: 1800, priority: 71, icon: '👼' },
  { name: 'Wizards', slug: 'wizards', description: 'Wizard coloring pages', searchVolume: 1500, priority: 72, icon: '🧙' },
  { name: 'Castles', slug: 'castles', description: 'Castle coloring pages', searchVolume: 1600, priority: 73, icon: '🏰' },
  { name: 'Mythical Creatures', slug: 'mythical-creatures', description: 'Mythical creature coloring pages', searchVolume: 1400, priority: 74, icon: '🦅' },

  // Nature & Flowers - 6 categories
  { name: 'Flowers', slug: 'flowers', description: 'Beautiful flower coloring pages', searchVolume: 3500, priority: 75, icon: '🌺' },
  { name: 'Trees', slug: 'trees', description: 'Tree coloring pages', searchVolume: 1700, priority: 76, icon: '🌳' },
  { name: 'Landscapes', slug: 'landscapes', description: 'Nature landscape coloring pages', searchVolume: 1900, priority: 77, icon: '🏞️' },
  { name: 'Rainbows', slug: 'rainbows', description: 'Rainbow coloring pages', searchVolume: 2200, priority: 78, icon: '🌈' },
  { name: 'Sun Moon Stars', slug: 'sun-moon-stars', description: 'Celestial coloring pages', searchVolume: 1500, priority: 79, icon: '🌙' },
  { name: 'Seasons', slug: 'seasons', description: 'Four seasons coloring pages', searchVolume: 1600, priority: 80, icon: '🍂' },

  // Mandalas & Abstract - 4 categories
  { name: 'Mandalas', slug: 'mandalas', description: 'Mandala coloring pages for adults', searchVolume: 5800, priority: 81, icon: '🔮' },
  { name: 'Geometric Patterns', slug: 'geometric-patterns', description: 'Geometric pattern coloring pages', searchVolume: 2400, priority: 82, icon: '◇' },
  { name: 'Zentangle', slug: 'zentangle', description: 'Zentangle coloring pages', searchVolume: 2100, priority: 83, icon: '🎨' },
  { name: 'Abstract Art', slug: 'abstract-art', description: 'Abstract art coloring pages', searchVolume: 1800, priority: 84, icon: '🖼️' },

  // Vehicles - 5 categories
  { name: 'Cars', slug: 'cars', description: 'Car coloring pages', searchVolume: 3200, priority: 85, icon: '🚗' },
  { name: 'Trucks', slug: 'trucks', description: 'Truck coloring pages', searchVolume: 2500, priority: 86, icon: '🚚' },
  { name: 'Airplanes', slug: 'airplanes', description: 'Airplane coloring pages', searchVolume: 2100, priority: 87, icon: '✈️' },
  { name: 'Trains', slug: 'trains', description: 'Train coloring pages', searchVolume: 1900, priority: 88, icon: '🚂' },
  { name: 'Boats', slug: 'boats', description: 'Boat and ship coloring pages', searchVolume: 1600, priority: 89, icon: '⛵' },

  // Educational - 5 categories
  { name: 'Alphabet', slug: 'alphabet', description: 'Alphabet letter coloring pages', searchVolume: 4200, priority: 90, icon: '🔤' },
  { name: 'Numbers', slug: 'numbers', description: 'Number coloring pages', searchVolume: 3500, priority: 91, icon: '🔢' },
  { name: 'Shapes', slug: 'shapes', description: 'Shape coloring pages', searchVolume: 2800, priority: 92, icon: '⭕' },
  { name: 'Solar System', slug: 'solar-system', description: 'Solar system and planets coloring pages', searchVolume: 2200, priority: 93, icon: '🪐' },
  { name: 'Professions', slug: 'professions', description: 'Profession and occupation coloring pages', searchVolume: 1900, priority: 94, icon: '👨‍⚕️' },

  // Food & Miscellaneous - 6 categories
  { name: 'Food', slug: 'food', description: 'Food coloring pages', searchVolume: 2600, priority: 95, icon: '🍕' },
  { name: 'Fruits', slug: 'fruits', description: 'Fruit coloring pages', searchVolume: 2300, priority: 96, icon: '🍎' },
  { name: 'Desserts', slug: 'desserts', description: 'Dessert and candy coloring pages', searchVolume: 2000, priority: 97, icon: '🍰' },
  { name: 'Sports', slug: 'sports', description: 'Sports coloring pages', searchVolume: 2400, priority: 98, icon: '⚽' },
  { name: 'Music', slug: 'music', description: 'Music instrument coloring pages', searchVolume: 1700, priority: 99, icon: '🎵' },
  { name: 'Space', slug: 'space', description: 'Space and astronaut coloring pages', searchVolume: 2500, priority: 100, icon: '🚀' },
];

async function main() {
  console.log('🌱 Seeding database...');

  // Create test admin account (john@doe.com / johndoe123)
  const hashedPassword = await bcrypt.hash('johndoe123', 10);
  await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      password: hashedPassword,
      fullName: 'John Doe',
      role: 'admin',
    },
  });

  console.log('✅ Admin user created: john@doe.com / johndoe123');

  // Create additional admin account
  const adminHashedPassword = await bcrypt.hash('admin123', 10);
  await prisma.user.upsert({
    where: { email: 'admin@pluscoloring.com' },
    update: {},
    create: {
      email: 'admin@pluscoloring.com',
      password: adminHashedPassword,
      fullName: 'Admin User',
      role: 'admin',
    },
  });

  console.log('✅ Admin user created: admin@pluscoloring.com / admin123');

  // Create categories with SEO metadata
  for (const category of categories) {
    const metaTitle = `${category.name} Coloring Pages - Free Printable | PlusColoring`;
    const metaDescription = `Download and print free ${category.name.toLowerCase()} coloring pages. Perfect for kids and adults. High-quality printable ${category.name.toLowerCase()} coloring sheets.`;

    await prisma.category.upsert({
      where: { slug: category.slug },
      update: {},
      create: {
        name: category.name,
        slug: category.slug,
        description: category.description,
        metaTitle,
        metaDescription,
        icon: category.icon,
        searchVolume: category.searchVolume,
        priority: category.priority,
      },
    });
  }

  console.log(`✅ Created ${categories.length} categories`);
  console.log('🎉 Seeding completed!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
