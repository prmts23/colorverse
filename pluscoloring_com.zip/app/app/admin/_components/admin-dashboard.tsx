
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Trash2, Edit, Eye, Download, Upload as UploadIcon } from 'lucide-react';
import { toast } from 'sonner';
import { OptimizedImage } from '@/components/optimized-image';

export function AdminDashboard() {
  const [pages, setPages] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPages();
  }, []);

  const loadPages = async () => {
    try {
      const response = await fetch('/api/admin/coloring-pages');
      const data = await response.json();
      setPages(data || []);
    } catch (error) {
      console.error('Load error:', error);
      toast.error('Failed to load coloring pages');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this coloring page?')) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/coloring-pages/${id}`, {
        method: 'DELETE',
      });

      if (response?.ok) {
        toast.success('Coloring page deleted');
        loadPages();
      } else {
        toast.error('Failed to delete');
      }
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('An error occurred');
    }
  };

  const togglePublished = async (id: string, published: boolean) => {
    try {
      const response = await fetch(`/api/admin/coloring-pages/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ published: !published }),
      });

      if (response?.ok) {
        toast.success(`Coloring page ${!published ? 'published' : 'unpublished'}`);
        loadPages();
      } else {
        toast.error('Failed to update');
      }
    } catch (error) {
      console.error('Update error:', error);
      toast.error('An error occurred');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Coloring Pages</h1>
          <p className="text-gray-600 mt-1">{pages?.length} total pages</p>
        </div>
        <Link
          href="/admin/upload"
          className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors"
        >
          <UploadIcon className="w-5 h-5" />
          <span>Upload New</span>
        </Link>
      </div>

      {pages?.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-lg">
          <p className="text-xl text-gray-500 mb-4">No coloring pages yet</p>
          <Link
            href="/admin/upload"
            className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors"
          >
            <UploadIcon className="w-5 h-5" />
            <span>Upload First Page</span>
          </Link>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Image
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Category
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Stats
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {pages?.map((page: any) => (
                  <tr key={page?.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="relative w-16 h-20 bg-gray-100 rounded">
                        <OptimizedImage
                          src={page?.cloudStoragePath || ''}
                          alt={page?.altText || ''}
                          className="object-cover rounded"
                        />
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{page?.title}</div>
                      <div className="text-sm text-gray-500">{page?.slug}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{page?.category?.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <div className="flex items-center gap-1">
                          <Download className="w-4 h-4" />
                          <span>{page?.downloads || 0}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          <span>{page?.views || 0}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => togglePublished(page?.id, page?.published)}
                        className={`px-3 py-1 text-xs font-semibold rounded-full ${
                          page?.published
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {page?.published ? 'Published' : 'Draft'}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          href={`/${page?.category?.slug}/${page?.slug}`}
                          target="_blank"
                          className="text-blue-600 hover:text-blue-900"
                        >
                          <Eye className="w-5 h-5" />
                        </Link>
                        <button
                          onClick={() => handleDelete(page?.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
