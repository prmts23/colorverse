
'use client';

import Link from 'next/link';
import { signOut, useSession } from 'next-auth/react';
import { Palette, LogOut, Upload, Grid } from 'lucide-react';

export function AdminHeader() {
  const { data: session } = useSession() || {};

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link href="/admin" className="flex items-center gap-2">
              <Palette className="w-6 h-6 text-purple-600" />
              <span className="text-xl font-bold text-gray-900">Admin Panel</span>
            </Link>

            <nav className="hidden md:flex items-center gap-6">
              <Link
                href="/admin"
                className="flex items-center gap-2 text-gray-700 hover:text-purple-600 transition-colors"
              >
                <Grid className="w-4 h-4" />
                <span>Dashboard</span>
              </Link>
              <Link
                href="/admin/upload"
                className="flex items-center gap-2 text-gray-700 hover:text-purple-600 transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>Upload</span>
              </Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">{session?.user?.email}</span>
            <button
              onClick={() => signOut({ callbackUrl: '/' })}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-red-600 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
