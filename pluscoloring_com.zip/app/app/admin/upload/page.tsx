
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth-options';
import { UploadForm } from './_components/upload-form';
import prisma from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getCategories() {
  return prisma.category.findMany({
    orderBy: { name: 'asc' },
  });
}

export default async function AdminUploadPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/admin/login');
  }

  const categories = await getCategories();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Upload Coloring Page</h1>
      <div className="bg-white rounded-lg shadow-lg p-8">
        <UploadForm categories={categories} />
      </div>
    </div>
  );
}
