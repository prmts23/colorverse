
import { LoginForm } from './_components/login-form';
import { Palette } from 'lucide-react';

export const metadata = {
  title: 'Admin Login | PlusColoring',
  description: 'Admin login for PlusColoring content management',
};

export default function AdminLoginPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mb-4">
              <Palette className="w-8 h-8 text-purple-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Admin Login</h1>
            <p className="text-gray-600">Sign in to manage coloring pages</p>
          </div>

          <LoginForm />
        </div>
      </div>
    </div>
  );
}
