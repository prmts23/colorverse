
import { Breadcrumbs } from '@/components/breadcrumbs';
import { Palette, Heart, Sparkles } from 'lucide-react';

export const metadata = {
  title: 'About Us | PlusColoring',
  description: 'Learn more about PlusColoring and our mission to provide free, high-quality coloring pages for everyone.',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Breadcrumbs items={[{ label: 'About' }]} />

        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">About PlusColoring</h1>

          <div className="bg-white rounded-lg shadow-md p-8 space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Palette className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Our Mission</h2>
                <p className="text-gray-700">
                  PlusColoring is dedicated to providing free, high-quality coloring pages for people of all ages. 
                  We believe that creativity and artistic expression should be accessible to everyone, whether you're 
                  a child discovering the joy of coloring or an adult seeking a relaxing creative outlet.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-6 h-6 text-pink-600" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-2">What We Offer</h2>
                <p className="text-gray-700 mb-4">
                  Our collection features over 100 carefully curated categories, including:
                </p>
                <ul className="text-gray-700 space-y-2">
                  <li>• Animals, from cute pets to wild creatures</li>
                  <li>• Popular characters from Disney, video games, and more</li>
                  <li>• Educational themes like alphabet and numbers</li>
                  <li>• Beautiful mandalas and geometric patterns for adults</li>
                  <li>• Seasonal and holiday-themed pages</li>
                  <li>• And so much more!</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Heart className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Why Choose Us</h2>
                <p className="text-gray-700">
                  All our coloring pages are carefully optimized for printing, ensuring you get the best quality 
                  results every time. Our easy-to-use platform makes it simple to find, download, and print the 
                  perfect coloring page in seconds. Plus, everything is completely free!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
