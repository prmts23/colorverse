
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { SessionProviderWrapper } from '@/components/session-provider-wrapper';
import { Providers } from './providers';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'PlusColoring - Free Printable Coloring Pages for Kids & Adults',
  description: 'Download and print thousands of free coloring pages. Explore 100+ categories including animals, Disney characters, mandalas, and more.',
  keywords: 'coloring pages, coloring book kids, free printable, coloring sheets, kids activities',
  metadataBase: new URL('https://pluscoloring.com'),
  openGraph: {
    title: 'PlusColoring - Free Printable Coloring Pages',
    description: 'Download and print thousands of free coloring pages for kids and adults',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        <Providers>
          <SessionProviderWrapper>
            <div className="flex flex-col min-h-screen">
              <Header />
              <main className="flex-1">{children}</main>
              <Footer />
            </div>
          </SessionProviderWrapper>
        </Providers>
      </body>
    </html>
  );
}
