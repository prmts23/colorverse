
import { CategoryCard } from '@/components/category-card';
import { Breadcrumbs } from '@/components/breadcrumbs';
import { AdsensePlaceholder } from '@/components/adsense-placeholder';
import prisma from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata = {
  title: 'All Coloring Page Categories | PlusColoring',
  description: 'Browse 100+ coloring page categories including animals, Disney characters, mandalas, vehicles, and more.',
};

async function getAllCategories() {
  return prisma.category.findMany({
    orderBy: { priority: 'asc' },
    include: {
      _count: {
        select: { pages: true },
      },
    },
  });
}

export default async function CategoriesPage() {
  const categories = await getAllCategories();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Breadcrumbs items={[{ label: 'Categories' }]} />

        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          All Coloring Categories
        </h1>
        <p className="text-lg text-gray-600 mb-8">
          Explore our complete collection of {categories?.length} categories with thousands of coloring pages
        </p>

        <div className="mb-8">
          <AdsensePlaceholder slot="header" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categories?.map((category: any, index: number) => (
            <CategoryCard key={category?.id} category={category} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
}
