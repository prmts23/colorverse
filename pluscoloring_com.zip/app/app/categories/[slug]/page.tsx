
import { notFound } from 'next/navigation';
import { Breadcrumbs } from '@/components/breadcrumbs';
import { ColoringPageCard } from '@/components/coloring-page-card';
import { AdsensePlaceholder } from '@/components/adsense-placeholder';
import prisma from '@/lib/db';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';

async function getCategory(slug: string) {
  return prisma.category.findUnique({
    where: { slug },
    include: {
      pages: {
        where: { published: true },
        orderBy: { createdAt: 'desc' },
      },
    },
  });
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const category = await getCategory(params.slug);

  if (!category) {
    return {
      title: 'Category Not Found',
    };
  }

  return {
    title: category?.metaTitle || `${category?.name} Coloring Pages | PlusColoring`,
    description: category?.metaDescription || category?.description || `Download and print free ${category?.name?.toLowerCase()} coloring pages`,
  };
}

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const category = await getCategory(params.slug);

  if (!category) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Breadcrumbs
          items={[
            { label: 'Categories', href: '/categories' },
            { label: category?.name || '' },
          ]}
        />

        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <span className="text-5xl">{category?.icon}</span>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">
                {category?.name} Coloring Pages
              </h1>
              <p className="text-lg text-gray-600 mt-2">
                {category?.pages?.length || 0} coloring pages available
              </p>
            </div>
          </div>
          {category?.description && (
            <p className="text-gray-700">{category.description}</p>
          )}
        </div>

        <div className="mb-8">
          <AdsensePlaceholder slot="header" />
        </div>

        {category?.pages?.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {category?.pages?.map((page: any, index: number) => (
              <ColoringPageCard
                key={page?.id}
                page={{
                  ...page,
                  category: {
                    name: category?.name || '',
                    slug: category?.slug || '',
                  },
                }}
                index={index}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-gray-500">
              No coloring pages available yet in this category.
            </p>
            <p className="text-gray-400 mt-2">Check back soon for updates!</p>
          </div>
        )}
      </div>
    </div>
  );
}
