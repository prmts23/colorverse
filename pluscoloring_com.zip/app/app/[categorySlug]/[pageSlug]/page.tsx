
import { notFound } from 'next/navigation';
import { Breadcrumbs } from '@/components/breadcrumbs';
import { AdsensePlaceholder } from '@/components/adsense-placeholder';
import { ColoringPageDetail } from './_components/coloring-page-detail';
import prisma from '@/lib/db';
import type { Metadata } from 'next';
import { generateImageSchema } from '@/lib/image-utils';

export const dynamic = 'force-dynamic';

async function getColoringPage(categorySlug: string, pageSlug: string) {
  const category = await prisma.category.findUnique({
    where: { slug: categorySlug },
  });

  if (!category) return null;

  return prisma.coloringPage.findFirst({
    where: {
      slug: pageSlug,
      categoryId: category.id,
    },
    include: {
      category: true,
    },
  });
}

async function getRelatedPages(categoryId: string, currentPageId: string) {
  return prisma.coloringPage.findMany({
    where: {
      categoryId,
      published: true,
      id: { not: currentPageId },
    },
    take: 4,
    orderBy: { createdAt: 'desc' },
    include: {
      category: true,
    },
  });
}

export async function generateMetadata({
  params,
}: {
  params: { categorySlug: string; pageSlug: string };
}): Promise<Metadata> {
  const page = await getColoringPage(params.categorySlug, params.pageSlug);

  if (!page) {
    return {
      title: 'Coloring Page Not Found',
    };
  }

  return {
    title: page?.metaTitle || `${page?.title} | PlusColoring`,
    description: page?.metaDescription || page?.description || `Download and print ${page?.title?.toLowerCase()} coloring page`,
  };
}

export default async function ColoringPageDetailPage({
  params,
}: {
  params: { categorySlug: string; pageSlug: string };
}) {
  const page = await getColoringPage(params.categorySlug, params.pageSlug);

  if (!page) {
    notFound();
  }

  const relatedPages = await getRelatedPages(page?.categoryId, page?.id);

  // Generate structured data for SEO
  const imageSchema = generateImageSchema(
    page?.cloudStoragePath || '',
    page?.title || '',
    page?.description || page?.altText || '',
    page?.width || 800,
    page?.height || 1000
  );

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(imageSchema) }}
      />

      <div className="min-h-screen bg-gray-50">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumbs
            items={[
              { label: 'Categories', href: '/categories' },
              { label: page?.category?.name || '', href: `/categories/${page?.category?.slug}` },
              { label: page?.title || '' },
            ]}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <ColoringPageDetail page={page} />
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <AdsensePlaceholder slot="sidebar" />
            </div>
          </div>

          {/* Related Pages */}
          {relatedPages?.length > 0 && (
            <div className="mt-16">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                More from {page?.category?.name}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedPages?.map((relatedPage: any, index: number) => {
                  const { ColoringPageCard } = require('@/components/coloring-page-card');
                  return (
                    <ColoringPageCard
                      key={relatedPage?.id}
                      page={relatedPage}
                      index={index}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
