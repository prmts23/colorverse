
'use client';

import { useState } from 'react';
import { Download, Printer, Share2, Eye, Loader2 } from 'lucide-react';
import { OptimizedImage } from '@/components/optimized-image';
import { toast } from 'sonner';

interface ColoringPageDetailProps {
  page: {
    id: string;
    title: string;
    slug: string;
    description: string | null;
    altText: string;
    cloudStoragePath: string;
    downloads: number;
    views: number;
    category: {
      name: string;
      slug: string;
    };
  };
}

export function ColoringPageDetail({ page }: ColoringPageDetailProps) {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch(`/api/coloring-pages/${page?.slug}/download`);
      const data = await response.json();

      if (data?.downloadUrl) {
        const link = document.createElement('a');
        link.href = data.downloadUrl;
        link.download = data?.fileName || 'coloring-page.webp';
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        toast.success('Download started!');
      }
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handlePrint = async () => {
    try {
      const response = await fetch(`/api/coloring-pages/${page?.slug}/download`);
      const data = await response.json();

      if (data?.downloadUrl) {
        const printWindow = window.open(data.downloadUrl, '_blank');
        printWindow?.addEventListener('load', () => {
          printWindow?.print();
        });
        toast.success('Opening print dialog...');
      }
    } catch (error) {
      console.error('Print error:', error);
      toast.error('Failed to print. Please try again.');
    }
  };

  const handleShare = async () => {
    const url = window?.location?.href;
    const shareData = {
      title: page?.title,
      text: `Check out this ${page?.title} coloring page!`,
      url,
    };

    if (navigator?.share) {
      try {
        await navigator.share(shareData);
        toast.success('Shared successfully!');
      } catch (error) {
        if ((error as Error)?.name !== 'AbortError') {
          console.error('Share error:', error);
        }
      }
    } else {
      try {
        await navigator?.clipboard?.writeText(url);
        toast.success('Link copied to clipboard!');
      } catch (error) {
        console.error('Copy error:', error);
        toast.error('Failed to copy link.');
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Image */}
      <div className="relative aspect-[3/4] bg-gray-100">
        <OptimizedImage
          src={page?.cloudStoragePath || ''}
          alt={page?.altText || ''}
          priority
        />
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Title and Category */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{page?.title}</h1>
          <p className="text-lg text-purple-600">{page?.category?.name}</p>
        </div>

        {/* Description */}
        {page?.description && (
          <div>
            <h2 className="font-semibold text-gray-900 mb-2">About this coloring page</h2>
            <p className="text-gray-700">{page.description}</p>
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center gap-6 text-sm text-gray-500">
          <div className="flex items-center gap-2">
            <Download className="w-4 h-4" />
            <span>{page?.downloads || 0} downloads</span>
          </div>
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            <span>{page?.views || 0} views</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Downloading...</span>
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span>Download</span>
              </>
            )}
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-pink-600 text-white rounded-lg font-semibold hover:bg-pink-700 transition-colors"
          >
            <Printer className="w-5 h-5" />
            <span>Print</span>
          </button>
          <button
            onClick={handleShare}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            <Share2 className="w-5 h-5" />
            <span>Share</span>
          </button>
        </div>

        {/* Tips */}
        <div className="bg-purple-50 rounded-lg p-4">
          <h3 className="font-semibold text-purple-900 mb-2">💡 Coloring Tips</h3>
          <ul className="text-sm text-purple-800 space-y-1">
            <li>• Use high-quality paper for best results</li>
            <li>• Try different coloring tools: crayons, markers, or colored pencils</li>
            <li>• Take your time and enjoy the creative process</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
