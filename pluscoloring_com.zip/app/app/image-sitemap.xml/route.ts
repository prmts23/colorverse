
import { NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { downloadFile } from '@/lib/s3';

export const dynamic = 'force-dynamic';

export async function GET() {
  const baseUrl = 'https://pluscoloring.com';

  try {
    const pages = await prisma.coloringPage.findMany({
      where: { published: true },
      include: {
        category: {
          select: { slug: true },
        },
      },
    });

    const urlEntries = await Promise.all(
      pages?.map(async (page: any) => {
        const pageUrl = `${baseUrl}/${page?.category?.slug}/${page?.slug}`;
        
        // Generate signed URL for the image (in production, use CDN URL)
        let imageUrl = '';
        try {
          imageUrl = await downloadFile(page?.cloudStoragePath);
        } catch (error) {
          console.error('Error getting image URL:', error);
          imageUrl = `${baseUrl}/placeholder.webp`;
        }

        return `
    <url>
      <loc>${pageUrl}</loc>
      <image:image>
        <image:loc>${imageUrl}</image:loc>
        <image:title>${page?.title?.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</image:title>
        <image:caption>${page?.altText?.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</image:caption>
      </image:image>
    </url>`;
      })
    );

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  ${urlEntries.join('')}
</urlset>`;

    return new NextResponse(xml, {
      headers: {
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      },
    });
  } catch (error) {
    console.error('Image sitemap error:', error);
    return new NextResponse('Error generating image sitemap', { status: 500 });
  }
}
