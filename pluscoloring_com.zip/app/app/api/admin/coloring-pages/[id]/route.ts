
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import prisma from '@/lib/db';
import { deleteFile } from '@/lib/s3';

export const dynamic = 'force-dynamic';

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { title, description, altText, categoryId, featured, published } = body;

    const updatedPage = await prisma.coloringPage.update({
      where: { id: params.id },
      data: {
        title: title || undefined,
        description: description !== undefined ? description : undefined,
        altText: altText || undefined,
        categoryId: categoryId || undefined,
        featured: featured !== undefined ? featured : undefined,
        published: published !== undefined ? published : undefined,
      },
      include: {
        category: true,
      },
    });

    return NextResponse.json(updatedPage);
  } catch (error) {
    console.error('Update error:', error);
    return NextResponse.json(
      { error: 'Failed to update coloring page' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const page = await prisma.coloringPage.findUnique({
      where: { id: params.id },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Coloring page not found' },
        { status: 404 }
      );
    }

    // Delete from S3
    try {
      await deleteFile(page.cloudStoragePath);
    } catch (error) {
      console.error('S3 delete error:', error);
    }

    // Delete from database
    await prisma.coloringPage.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: 'Coloring page deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    return NextResponse.json(
      { error: 'Failed to delete coloring page' },
      { status: 500 }
    );
  }
}
