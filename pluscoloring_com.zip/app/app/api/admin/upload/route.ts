
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import prisma from '@/lib/db';
import { uploadFile } from '@/lib/s3';
import { generateSlug, generateAltText, generateMetaTitle, generateMetaDescription, sanitizeFileName } from '@/lib/seo';
import sharp from 'sharp';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const categoryId = formData.get('categoryId') as string;
    const altText = formData.get('altText') as string;
    const featured = formData.get('featured') === 'true';

    if (!file || !title || !categoryId) {
      return NextResponse.json(
        { error: 'File, title, and category are required' },
        { status: 400 }
      );
    }

    // Get category for SEO
    const category = await prisma.category.findUnique({
      where: { id: categoryId },
    });

    if (!category) {
      return NextResponse.json(
        { error: 'Category not found' },
        { status: 404 }
      );
    }

    // Convert image to WebP and get dimensions
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    const image = sharp(buffer);
    const metadata = await image.metadata();
    const webpBuffer = await image.webp({ quality: 90 }).toBuffer();

    // Generate SEO-friendly filename
    const slug = generateSlug(title);
    const fileName = sanitizeFileName(`${slug}.webp`);

    // Upload to S3
    const cloudStoragePath = await uploadFile(webpBuffer, fileName);

    // Generate SEO metadata
    const finalAltText = altText || generateAltText(title, category.name);
    const metaTitle = generateMetaTitle(title, category.name);
    const metaDescription = description || generateMetaDescription(title, category.name);

    // Create coloring page record
    const coloringPage = await prisma.coloringPage.create({
      data: {
        title,
        slug,
        description: description || null,
        altText: finalAltText,
        cloudStoragePath,
        fileName,
        fileSize: webpBuffer.length,
        width: metadata.width || 0,
        height: metadata.height || 0,
        metaTitle,
        metaDescription,
        categoryId,
        featured,
        published: true,
      },
      include: {
        category: true,
      },
    });

    return NextResponse.json(
      { message: 'Coloring page created successfully', page: coloringPage },
      { status: 201 }
    );
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json(
      { error: 'Failed to upload coloring page' },
      { status: 500 }
    );
  }
}
