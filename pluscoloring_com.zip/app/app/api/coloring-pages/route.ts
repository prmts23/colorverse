
import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = searchParams.get('limit');
    const featured = searchParams.get('featured');
    const categoryId = searchParams.get('categoryId');

    const where: any = { published: true };
    
    if (featured === 'true') {
      where.featured = true;
    }
    
    if (categoryId) {
      where.categoryId = categoryId;
    }

    const pages = await prisma.coloringPage.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit ? parseInt(limit) : undefined,
      include: {
        category: true,
      },
    });

    return NextResponse.json(pages);
  } catch (error) {
    console.error('Coloring pages fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch coloring pages' },
      { status: 500 }
    );
  }
}
