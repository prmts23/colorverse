
import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { slug: string } }
) {
  try {
    const page = await prisma.coloringPage.findUnique({
      where: { slug: params.slug },
      include: {
        category: true,
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Coloring page not found' },
        { status: 404 }
      );
    }

    // Increment views
    await prisma.coloringPage.update({
      where: { id: page.id },
      data: { views: { increment: 1 } },
    });

    return NextResponse.json(page);
  } catch (error) {
    console.error('Coloring page fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch coloring page' },
      { status: 500 }
    );
  }
}
