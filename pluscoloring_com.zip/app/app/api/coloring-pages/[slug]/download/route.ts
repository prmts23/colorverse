
import { NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { downloadFile } from '@/lib/s3';

export const dynamic = 'force-dynamic';

export async function GET(
  request: Request,
  { params }: { params: { slug: string } }
) {
  try {
    const page = await prisma.coloringPage.findUnique({
      where: { slug: params.slug },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Coloring page not found' },
        { status: 404 }
      );
    }

    // Increment downloads
    await prisma.coloringPage.update({
      where: { id: page.id },
      data: { downloads: { increment: 1 } },
    });

    const signedUrl = await downloadFile(page.cloudStoragePath);

    return NextResponse.json({ downloadUrl: signedUrl, fileName: page.fileName });
  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json(
      { error: 'Failed to generate download link' },
      { status: 500 }
    );
  }
}
