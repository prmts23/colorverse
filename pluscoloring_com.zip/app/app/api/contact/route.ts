
import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

// Create a simple ContactMessage model for storing contact form submissions
// We'll add this to Prisma schema later if needed, for now just return success

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, subject, message } = body;

    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { error: 'All fields are required' },
        { status: 400 }
      );
    }

    // In a real app, you would save this to database or send email
    // For now, just return success
    console.log('Contact form submission:', { name, email, subject, message });

    return NextResponse.json(
      { message: 'Contact form submitted successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Contact form error:', error);
    return NextResponse.json(
      { error: 'Failed to submit contact form' },
      { status: 500 }
    );
  }
}
