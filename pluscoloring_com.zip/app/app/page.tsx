
import Link from 'next/link';
import { Palette, Download, Printer, TrendingUp } from 'lucide-react';
import { CategoryCard } from '@/components/category-card';
import { ColoringPageCard } from '@/components/coloring-page-card';
import { AdsensePlaceholder } from '@/components/adsense-placeholder';
import prisma from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getFeaturedCategories() {
  return prisma.category.findMany({
    orderBy: { priority: 'asc' },
    take: 12,
    include: {
      _count: {
        select: { pages: true },
      },
    },
  });
}

async function getPopularPages() {
  return prisma.coloringPage.findMany({
    where: { published: true },
    orderBy: { downloads: 'desc' },
    take: 8,
    include: {
      category: true,
    },
  });
}

export default async function HomePage() {
  const categories = await getFeaturedCategories();
  const popularPages = await getPopularPages();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-16">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Free Printable Coloring Pages for{' '}
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Everyone
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Discover thousands of high-quality coloring pages across 100+ categories. Perfect for kids, adults, and creative minds of all ages.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                href="/categories"
                className="px-8 py-3 bg-purple-600 text-white rounded-full font-semibold hover:bg-purple-700 transition-colors shadow-lg hover:shadow-xl"
              >
                Explore Categories
              </Link>
            </div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">100+ Categories</h3>
              <p className="text-sm text-gray-600">
                From animals to mandalas, find the perfect coloring page
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Download className="w-6 h-6 text-pink-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Easy Download</h3>
              <p className="text-sm text-gray-600">
                High-quality images ready to download and print
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Printer className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Print Ready</h3>
              <p className="text-sm text-gray-600">
                Optimized for printing on standard paper sizes
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* AdSense Placeholder */}
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AdsensePlaceholder slot="header" />
      </div>

      {/* Popular Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Popular Categories</h2>
            <Link
              href="/categories"
              className="text-purple-600 hover:text-purple-700 font-semibold"
            >
              View All →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {categories?.map((category: any, index: number) => (
              <CategoryCard key={category?.id} category={category} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Popular Coloring Pages */}
      {popularPages?.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-8">
              <TrendingUp className="w-8 h-8 text-purple-600" />
              <h2 className="text-3xl font-bold text-gray-900">Most Downloaded</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {popularPages?.map((page: any, index: number) => (
                <ColoringPageCard key={page?.id} page={page} index={index} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-br from-purple-600 to-pink-600">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Start Coloring Today
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Join thousands of creative people exploring our collection
          </p>
          <Link
            href="/categories"
            className="inline-block px-8 py-3 bg-white text-purple-600 rounded-full font-semibold hover:bg-gray-100 transition-colors shadow-lg"
          >
            Browse All Categories
          </Link>
        </div>
      </section>
    </div>
  );
}
