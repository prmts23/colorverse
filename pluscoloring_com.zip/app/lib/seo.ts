
export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function generateAltText(title: string, categoryName: string, maxLength: number = 125): string {
  const altText = `${title} - ${categoryName} coloring page`;
  return altText.length > maxLength ? altText.substring(0, maxLength - 3) + '...' : altText;
}

export function generateMetaTitle(title: string, categoryName?: string): string {
  if (categoryName) {
    return `${title} - ${categoryName} Coloring Page | PlusColoring`;
  }
  return `${title} Coloring Page | PlusColoring`;
}

export function generateMetaDescription(title: string, categoryName: string): string {
  return `Download and print free ${title.toLowerCase()} coloring page from our ${categoryName.toLowerCase()} collection. High-quality printable coloring sheet for kids and adults.`;
}

export function sanitizeFileName(fileName: string): string {
  return fileName
    .toLowerCase()
    .replace(/[^a-z0-9.]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
