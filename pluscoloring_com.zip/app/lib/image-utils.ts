
export function getImageDimensions(width: number, height: number) {
  const aspectRatio = width / height;
  
  // Standard coloring page dimensions
  const maxWidth = 1200;
  const maxHeight = 1600;
  
  let finalWidth = width;
  let finalHeight = height;
  
  if (width > maxWidth) {
    finalWidth = maxWidth;
    finalHeight = Math.round(maxWidth / aspectRatio);
  }
  
  if (finalHeight > maxHeight) {
    finalHeight = maxHeight;
    finalWidth = Math.round(maxHeight * aspectRatio);
  }
  
  return { width: finalWidth, height: finalHeight, aspectRatio };
}

export function generateImageSchema(
  imageUrl: string,
  title: string,
  description: string,
  width: number,
  height: number
) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ImageObject',
    contentUrl: imageUrl,
    name: title,
    description: description,
    width: width,
    height: height,
    encodingFormat: 'image/webp',
    license: 'https://pluscoloring.com/license',
  };
}
