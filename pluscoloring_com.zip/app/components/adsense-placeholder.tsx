
export function AdsensePlaceholder({ slot }: { slot: 'header' | 'sidebar' | 'content' }) {
  const heights = {
    header: 'h-24',
    sidebar: 'h-96',
    content: 'h-64',
  };

  return (
    <div
      className={`${heights[slot]} bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300`}
    >
      <div className="text-center text-gray-500">
        <p className="font-semibold">Google AdSense</p>
        <p className="text-sm">{slot} placement</p>
      </div>
    </div>
  );
}
