
'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface CategoryCardProps {
  category: {
    id: string;
    name: string;
    slug: string;
    icon: string;
    description: string;
    _count?: {
      pages: number;
    };
  };
  index: number;
}

export function CategoryCard({ category, index }: CategoryCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      <Link
        href={`/categories/${category?.slug}`}
        className="block p-6 bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100"
      >
        <div className="flex items-center gap-4">
          <div className="text-4xl">{category?.icon}</div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-1">
              {category?.name}
            </h3>
            <p className="text-sm text-gray-500">
              {category?._count?.pages || 0} coloring pages
            </p>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
