
'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Download, Eye } from 'lucide-react';
import { OptimizedImage } from './optimized-image';

interface ColoringPageCardProps {
  page: {
    id: string;
    title: string;
    slug: string;
    altText: string;
    cloudStoragePath: string;
    downloads: number;
    views: number;
    category: {
      name: string;
      slug: string;
    };
  };
  index: number;
}

export function ColoringPageCard({ page, index }: ColoringPageCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      <Link
        href={`/${page?.category?.slug}/${page?.slug}`}
        className="block group"
      >
        <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
          {/* Image */}
          <div className="relative aspect-[3/4] bg-gray-100">
            <OptimizedImage
              src={page?.cloudStoragePath || ''}
              alt={page?.altText || ''}
              className="group-hover:scale-105 transition-transform duration-300"
            />
          </div>

          {/* Content */}
          <div className="p-4">
            <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
              {page?.title}
            </h3>
            <p className="text-sm text-purple-600 mb-3">{page?.category?.name}</p>
            
            {/* Stats */}
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <Download className="w-3 h-3" />
                <span>{page?.downloads || 0}</span>
              </div>
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>{page?.views || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
