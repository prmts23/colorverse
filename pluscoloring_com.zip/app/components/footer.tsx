
import Link from 'next/link';
import { Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t mt-16">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col items-center space-y-4">
          {/* Logo */}
          <Link href="/" className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            PlusColoring
          </Link>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-6 text-sm">
            <Link href="/categories" className="text-gray-600 hover:text-purple-600 transition-colors">
              Categories
            </Link>
            <Link href="/about" className="text-gray-600 hover:text-purple-600 transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-gray-600 hover:text-purple-600 transition-colors">
              Contact
            </Link>
          </nav>

          {/* Copyright */}
          <div className="text-center text-sm text-gray-500 pt-4">
            <p className="flex items-center justify-center gap-1">
              Made with <Heart className="w-4 h-4 text-red-500 fill-current" /> © {new Date().getFullYear()} PlusColoring. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
